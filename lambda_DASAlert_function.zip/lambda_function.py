import base64
import boto3
import zlib
import os

sns = boto3.client('sns')
snstopic_arn = os.environ['snstopic_arn']
def lambda_handler(event, context):
    json_msg = zlib.decompress(base64.b64decode(event['awslogs']['data']), 16 + zlib.MAX_WBITS).decode('utf-8')
    response = sns.publish(TopicArn=snstopic_arn,Message=json_msg)